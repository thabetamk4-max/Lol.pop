# Contributing
1. Fork the repo and create a branch.
2. `bun install` then `bun run dev`.
3. Run `bun test` before opening a pull request.
