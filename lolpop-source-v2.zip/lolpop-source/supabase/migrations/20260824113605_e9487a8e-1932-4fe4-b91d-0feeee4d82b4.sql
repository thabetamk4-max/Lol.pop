CREATE OR REPLACE FUNCTION public.set_template_author_username()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Pin authorship to the authenticated caller (admin/service_role keeps given author_id)
  IF auth.uid() IS NOT NULL THEN
    NEW.author_id := auth.uid();
  END IF;

  SELECT username INTO NEW.author_username
  FROM public.profiles
  WHERE id = NEW.author_id;

  IF NEW.author_username IS NULL THEN
    RAISE EXCEPTION 'No profile found for author_id %', NEW.author_id;
  END IF;

  RETURN NEW;
END;
$function$;