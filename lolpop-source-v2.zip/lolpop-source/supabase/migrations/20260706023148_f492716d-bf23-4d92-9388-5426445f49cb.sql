-- 1) Prevent author username spoofing on templates: always derive it from the owner's profile
CREATE OR REPLACE FUNCTION public.set_template_author_username()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  SELECT username INTO NEW.author_username
  FROM public.profiles
  WHERE id = NEW.author_id;

  IF NEW.author_username IS NULL THEN
    RAISE EXCEPTION 'No profile found for author_id %', NEW.author_id;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_set_template_author_username ON public.templates;
CREATE TRIGGER trg_set_template_author_username
BEFORE INSERT OR UPDATE ON public.templates
FOR EACH ROW EXECUTE FUNCTION public.set_template_author_username();

-- 2) Lock down SECURITY DEFINER counter functions: not callable by anon/authenticated
REVOKE EXECUTE ON FUNCTION public.increment_profile_views(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.increment_template_uses(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.increment_profile_views(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.increment_template_uses(uuid) TO service_role;