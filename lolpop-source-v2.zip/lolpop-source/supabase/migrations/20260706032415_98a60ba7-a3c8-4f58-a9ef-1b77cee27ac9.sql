-- Approval workflow for templates and profile directory
ALTER TABLE public.templates ADD COLUMN IF NOT EXISTS approved boolean NOT NULL DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS approved boolean NOT NULL DEFAULT true;

-- Grandfather existing templates so the gallery is not suddenly empty
UPDATE public.templates SET approved = true WHERE approved = false;

-- Public can only see approved templates; owners always see their own
DROP POLICY IF EXISTS "Templates are viewable by everyone" ON public.templates;
CREATE POLICY "Approved templates are viewable by everyone"
  ON public.templates FOR SELECT
  USING (approved = true OR auth.uid() = author_id);
