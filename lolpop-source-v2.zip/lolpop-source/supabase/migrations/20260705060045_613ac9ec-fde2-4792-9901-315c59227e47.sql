-- 1. Extend profiles with customization + assets + views
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS customization JSONB NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS avatar_url TEXT,
  ADD COLUMN IF NOT EXISTS background_url TEXT,
  ADD COLUMN IF NOT EXISTS background_type TEXT,
  ADD COLUMN IF NOT EXISTS audio_url TEXT,
  ADD COLUMN IF NOT EXISTS audio_name TEXT,
  ADD COLUMN IF NOT EXISTS views BIGINT NOT NULL DEFAULT 0;

-- 2. Atomic public view counter: bumps views and returns the profile row.
CREATE OR REPLACE FUNCTION public.increment_profile_views(_username TEXT)
RETURNS SETOF public.profiles
LANGUAGE sql
VOLATILE
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE public.profiles
     SET views = views + 1
   WHERE lower(username) = lower(_username)
  RETURNING *;
$$;

GRANT EXECUTE ON FUNCTION public.increment_profile_views(TEXT) TO anon, authenticated;

-- 3. Templates table (public gallery, owner-managed)
CREATE TABLE IF NOT EXISTS public.templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  author_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  author_username TEXT NOT NULL,
  name TEXT NOT NULL,
  customization JSONB NOT NULL DEFAULT '{}'::jsonb,
  avatar_url TEXT,
  background_url TEXT,
  background_type TEXT,
  uses BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT ON public.templates TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.templates TO authenticated;
GRANT ALL ON public.templates TO service_role;

ALTER TABLE public.templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Templates are viewable by everyone"
  ON public.templates FOR SELECT
  USING (true);

CREATE POLICY "Users can publish their own templates"
  ON public.templates FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own templates"
  ON public.templates FOR UPDATE TO authenticated
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can delete their own templates"
  ON public.templates FOR DELETE TO authenticated
  USING (auth.uid() = author_id);

CREATE TRIGGER update_templates_updated_at
  BEFORE UPDATE ON public.templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Bump a template's usage counter (public, safe).
CREATE OR REPLACE FUNCTION public.increment_template_uses(_template_id UUID)
RETURNS void
LANGUAGE sql
VOLATILE
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE public.templates SET uses = uses + 1 WHERE id = _template_id;
$$;

GRANT EXECUTE ON FUNCTION public.increment_template_uses(UUID) TO anon, authenticated;