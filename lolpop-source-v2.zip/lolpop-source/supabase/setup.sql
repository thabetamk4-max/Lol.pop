
CREATE TABLE public.profiles (
  id UUID NOT NULL PRIMARY KEY,
  username TEXT NOT NULL,
  display_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX profiles_username_lower_idx ON public.profiles (lower(username));

GRANT SELECT ON public.profiles TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Profiles are viewable by everyone"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.is_username_available(_username TEXT)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE lower(username) = lower(_username)
  );
$$;

GRANT EXECUTE ON FUNCTION public.is_username_available(TEXT) TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.is_username_available(_username TEXT)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE lower(username) = lower(_username)
  );
$$;
-- 1. Extend profiles with customization + assets + views
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS customization JSONB NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS avatar_url TEXT,
  ADD COLUMN IF NOT EXISTS background_url TEXT,
  ADD COLUMN IF NOT EXISTS background_type TEXT,
  ADD COLUMN IF NOT EXISTS audio_url TEXT,
  ADD COLUMN IF NOT EXISTS audio_name TEXT,
  ADD COLUMN IF NOT EXISTS views BIGINT NOT NULL DEFAULT 0;

-- 2. Atomic public view counter: bumps views and returns the profile row.
CREATE OR REPLACE FUNCTION public.increment_profile_views(_username TEXT)
RETURNS SETOF public.profiles
LANGUAGE sql
VOLATILE
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE public.profiles
     SET views = views + 1
   WHERE lower(username) = lower(_username)
  RETURNING *;
$$;

GRANT EXECUTE ON FUNCTION public.increment_profile_views(TEXT) TO anon, authenticated;

-- 3. Templates table (public gallery, owner-managed)
CREATE TABLE IF NOT EXISTS public.templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  author_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  author_username TEXT NOT NULL,
  name TEXT NOT NULL,
  customization JSONB NOT NULL DEFAULT '{}'::jsonb,
  avatar_url TEXT,
  background_url TEXT,
  background_type TEXT,
  uses BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT ON public.templates TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.templates TO authenticated;
GRANT ALL ON public.templates TO service_role;

ALTER TABLE public.templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Templates are viewable by everyone"
  ON public.templates FOR SELECT
  USING (true);

CREATE POLICY "Users can publish their own templates"
  ON public.templates FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own templates"
  ON public.templates FOR UPDATE TO authenticated
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can delete their own templates"
  ON public.templates FOR DELETE TO authenticated
  USING (auth.uid() = author_id);

CREATE TRIGGER update_templates_updated_at
  BEFORE UPDATE ON public.templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Bump a template's usage counter (public, safe).
CREATE OR REPLACE FUNCTION public.increment_template_uses(_template_id UUID)
RETURNS void
LANGUAGE sql
VOLATILE
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE public.templates SET uses = uses + 1 WHERE id = _template_id;
$$;

GRANT EXECUTE ON FUNCTION public.increment_template_uses(UUID) TO anon, authenticated;CREATE POLICY "Profile assets are publicly readable"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'profile-assets');

CREATE POLICY "Users can upload their own profile assets"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'profile-assets'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can update their own profile assets"
  ON storage.objects FOR UPDATE TO authenticated
  USING (
    bucket_id = 'profile-assets'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete their own profile assets"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'profile-assets'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );-- 1) Prevent author username spoofing on templates: always derive it from the owner's profile
CREATE OR REPLACE FUNCTION public.set_template_author_username()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  SELECT username INTO NEW.author_username
  FROM public.profiles
  WHERE id = NEW.author_id;

  IF NEW.author_username IS NULL THEN
    RAISE EXCEPTION 'No profile found for author_id %', NEW.author_id;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_set_template_author_username ON public.templates;
CREATE TRIGGER trg_set_template_author_username
BEFORE INSERT OR UPDATE ON public.templates
FOR EACH ROW EXECUTE FUNCTION public.set_template_author_username();

-- 2) Lock down SECURITY DEFINER counter functions: not callable by anon/authenticated
REVOKE EXECUTE ON FUNCTION public.increment_profile_views(text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.increment_template_uses(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.increment_profile_views(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.increment_template_uses(uuid) TO service_role;-- Approval workflow for templates and profile directory
ALTER TABLE public.templates ADD COLUMN IF NOT EXISTS approved boolean NOT NULL DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS approved boolean NOT NULL DEFAULT true;

-- Grandfather existing templates so the gallery is not suddenly empty
UPDATE public.templates SET approved = true WHERE approved = false;

-- Public can only see approved templates; owners always see their own
DROP POLICY IF EXISTS "Templates are viewable by everyone" ON public.templates;
CREATE POLICY "Approved templates are viewable by everyone"
  ON public.templates FOR SELECT
  USING (approved = true OR auth.uid() = author_id);
CREATE OR REPLACE FUNCTION public.set_template_author_username()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Pin authorship to the authenticated caller (admin/service_role keeps given author_id)
  IF auth.uid() IS NOT NULL THEN
    NEW.author_id := auth.uid();
  END IF;

  SELECT username INTO NEW.author_username
  FROM public.profiles
  WHERE id = NEW.author_id;

  IF NEW.author_username IS NULL THEN
    RAISE EXCEPTION 'No profile found for author_id %', NEW.author_id;
  END IF;

  RETURN NEW;
END;
$function$;REVOKE EXECUTE ON FUNCTION public.set_template_author_username() FROM anon, authenticated, PUBLIC;