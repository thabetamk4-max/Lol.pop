<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Application architecture
- Keep signed-in workspace routes under the client-only authenticated layout and public username profiles outside it; this avoids SSR session redirect loops and preserves shareable URLs.
- Store optional appearance and bio fields in customization JSON with centralized backward-compatible defaults; old profiles and templates must remain readable.
- Use ProfileScene and ProfileCard for both editor previews and public profiles; changes must render identically in both contexts.
- Apply templates as appearance-only patches; identity, personal text, and outbound links belong to the user and must not be replaced.
- Publish asset state only after a permanent storage URL resolves; ephemeral object URLs must never enter autosave.
- Provision profiles atomically through the Auth signup trigger; email-confirmation signup must never depend on a signed-in client insert.
- Keep dashboard section selection in validated URL search parameters so reload and browser history retain context.

- Authorize moderation through protected user_roles and authenticated server checks; never derive permissions from email or editable profile fields.
- Confine profile visual effects to ProfileScene so preview themes never alter the workspace.
