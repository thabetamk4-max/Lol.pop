CREATE OR REPLACE FUNCTION public.provision_signup_profile()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE chosen text;
BEGIN
  chosen := lower(trim(NEW.raw_user_meta_data ->> 'username'));
  IF chosen IS NULL OR chosen = '' THEN
    chosen := 'user_' || replace(NEW.id::text, '-', '');
  END IF;
  IF chosen !~ '^[a-z0-9_.]+$' OR chosen IN ('auth', 'dashboard', 'reset-password', 'api', 'sitemap.xml') THEN
    RAISE EXCEPTION 'Please choose a valid profile username';
  END IF;
  INSERT INTO public.profiles (id, username, display_name) VALUES (NEW.id, chosen, chosen);
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.provision_signup_profile() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.provision_signup_profile() TO service_role;
CREATE TRIGGER lolpop_profile_on_signup AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.provision_signup_profile();