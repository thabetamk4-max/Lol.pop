import { useEffect, useState } from "react";
import { CheckCircle2, Clock, Loader2, ShieldCheck, Trash2, Users, XCircle } from "lucide-react";
import {
  adminDeleteProfileFn,
  adminDeleteTemplateFn,
  adminListProfilesFn,
  adminListTemplatesFn,
  adminSetProfileApprovedFn,
  adminSetTemplateApprovedFn,
  type AdminProfile,
  type AdminTemplate,
} from "@/lib/admin.functions";
import { profileUrl } from "@/lib/site";

export function AdminPanel() {
  const [templates, setTemplates] = useState<AdminTemplate[]>([]);
  const [profiles, setProfiles] = useState<AdminProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const refresh = () => {
    setLoading(true);
    Promise.all([adminListTemplatesFn(), adminListProfilesFn()])
      .then(([t, p]) => {
        setTemplates(t);
        setProfiles(p);
      })
      .catch(() => {
        setTemplates([]);
        setProfiles([]);
      })
      .finally(() => setLoading(false));
  };

  useEffect(refresh, []);

  const run = async (id: string, fn: () => Promise<unknown>) => {
    setBusyId(id);
    try {
      await fn();
      refresh();
    } finally {
      setBusyId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="animate-spin text-primary" size={24} />
      </div>
    );
  }

  const pending = templates.filter((t) => !t.approved);
  const approved = templates.filter((t) => t.approved);

  return (
    <div className="space-y-10">
      <div className="flex items-center gap-2 rounded-2xl border border-primary/40 bg-primary/10 px-4 py-3 text-sm text-foreground">
        <ShieldCheck size={18} className="text-primary" />
        Admin control center — visible only to you.
      </div>

      {/* Template approval queue */}
      <section>
        <h2 className="flex items-center gap-2 text-2xl font-bold text-foreground">
          <Clock size={20} className="text-primary" /> Template approvals
          <span className="rounded-full bg-primary/20 px-2 py-0.5 text-xs text-primary">
            {pending.length} pending
          </span>
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Approve templates before they appear in the public gallery.
        </p>

        <div className="mt-4 space-y-2">
          {templates.length === 0 && (
            <p className="rounded-xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
              No templates yet.
            </p>
          )}
          {[...pending, ...approved].map((t) => (
            <div
              key={t.id}
              className="flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card/40 p-3"
            >
              <div className="h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-background">
                {t.background_url || t.avatar_url ? (
                  <img
                    src={(t.background_url || t.avatar_url) as string}
                    alt=""
                    className="h-full w-full object-cover"
                  />
                ) : null}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-foreground">{t.name}</p>
                <p className="truncate text-xs text-muted-foreground">
                  by @{t.author_username} · {t.uses} uses
                </p>
              </div>
              <span
                className={`rounded-full px-2 py-1 text-xs font-semibold ${
                  t.approved
                    ? "bg-green-500/15 text-green-500"
                    : "bg-amber-500/15 text-amber-500"
                }`}
              >
                {t.approved ? "Approved" : "Pending"}
              </span>
              {t.approved ? (
                <button
                  onClick={() => run(t.id, () => adminSetTemplateApprovedFn({ data: { id: t.id, approved: false } }))}
                  disabled={busyId === t.id}
                  className="flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
                >
                  <XCircle size={14} /> Unlist
                </button>
              ) : (
                <button
                  onClick={() => run(t.id, () => adminSetTemplateApprovedFn({ data: { id: t.id, approved: true } }))}
                  disabled={busyId === t.id}
                  className="flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
                >
                  <CheckCircle2 size={14} /> Approve
                </button>
              )}
              <button
                onClick={() => run(t.id, () => adminDeleteTemplateFn({ data: { id: t.id } }))}
                disabled={busyId === t.id}
                aria-label="Delete template"
                className="rounded-lg border border-border p-1.5 text-destructive hover:bg-destructive/10"
              >
                {busyId === t.id ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Claimed-link directory */}
      <section>
        <h2 className="flex items-center gap-2 text-2xl font-bold text-foreground">
          <Users size={20} className="text-primary" /> Claimed links
          <span className="rounded-full bg-primary/20 px-2 py-0.5 text-xs text-primary">
            {profiles.length}
          </span>
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Everyone who created their own /name. Approve, suspend or remove a link.
        </p>

        <div className="mt-4 space-y-2">
          {profiles.map((p) => (
            <div
              key={p.id}
              className="flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card/40 p-3"
            >
              <div className="min-w-0 flex-1">
                <a
                  href={profileUrl(p.username)}
                  target="_blank"
                  rel="noreferrer"
                  className="truncate text-sm font-semibold text-foreground hover:text-primary"
                >
                  /{p.username}
                </a>
                <p className="truncate text-xs text-muted-foreground">
                  {p.display_name || p.username} · {p.views} views
                </p>
              </div>
              <span
                className={`rounded-full px-2 py-1 text-xs font-semibold ${
                  p.approved ? "bg-green-500/15 text-green-500" : "bg-amber-500/15 text-amber-500"
                }`}
              >
                {p.approved ? "Approved" : "Suspended"}
              </span>
              {p.approved ? (
                <button
                  onClick={() => run(p.id, () => adminSetProfileApprovedFn({ data: { id: p.id, approved: false } }))}
                  disabled={busyId === p.id}
                  className="flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
                >
                  <XCircle size={14} /> Suspend
                </button>
              ) : (
                <button
                  onClick={() => run(p.id, () => adminSetProfileApprovedFn({ data: { id: p.id, approved: true } }))}
                  disabled={busyId === p.id}
                  className="flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground"
                >
                  <CheckCircle2 size={14} /> Approve
                </button>
              )}
              <button
                onClick={() => run(p.id, () => adminDeleteProfileFn({ data: { id: p.id } }))}
                disabled={busyId === p.id}
                aria-label="Delete link"
                className="rounded-lg border border-border p-1.5 text-destructive hover:bg-destructive/10"
              >
                {busyId === p.id ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
