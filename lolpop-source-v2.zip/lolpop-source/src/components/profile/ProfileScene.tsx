import type { CSSProperties, ReactNode } from 'react';
import { THEMES } from '@/lib/profile-data';
import type { ProfileView } from '@/lib/profile-store';
import { appearanceDefaults } from '@/lib/profile-settings';
import { Particles, Scanlines, CustomCursor } from './Effects';
export function ProfileScene({ view, children, preview = false }: { view: ProfileView; children: ReactNode; preview?: boolean }) {
 const a = appearanceDefaults(view.appearance);
 const theme = THEMES.find(t => t.id === view.theme)?.className ?? 'theme-noir';
 const variables = { '--profile-opacity': `${a.opacity}%`, '--profile-dimming': a.dimming / 100, '--profile-glow': `${a.glowIntensity}px` } as CSSProperties;
 return <div className={`profile-scene ${theme} ${view.theme === 'vintage' ? 'vintage-fx' : ''} ${view.cursor && !preview ? 'custom-cursor' : ''} relative flex w-full items-center justify-center overflow-hidden ${preview ? 'min-h-[550px] rounded-lg p-5' : 'min-h-dvh px-4 py-16'}`} style={variables} data-accent={a.accent} data-font={a.font} data-corners={a.corners} data-links={a.linkStyle} data-avatar={a.avatarShape} data-avatar-animation={a.avatarAnimation}>
 {view.background && <>{view.background.type.startsWith('video') ? <video src={view.background.url} autoPlay loop muted playsInline className="pointer-events-none absolute inset-0 h-full w-full object-cover"/> : <img src={view.background.url} alt="" className="pointer-events-none absolute inset-0 h-full w-full object-cover"/>}<div className="profile-dim pointer-events-none absolute inset-0"/></>}
 <Particles mode={view.particles}/>{!preview && <><Scanlines enabled={view.scanlines}/><CustomCursor enabled={view.cursor}/></>}
 <div className="relative z-10 w-full max-w-md">{children}</div></div>;
}
