import {
  Globe,
  Heart,
  Rocket,
  Users,
  Star,
  Music,
  Video,
  Camera,
  Mail,
  ShoppingBag,
  Gamepad2,
  Link as LinkIcon,
  Briefcase,
  Calendar,
  BookOpen,
  Gift,
  ArrowUpRight,
  type LucideIcon,
} from "lucide-react";
import type { LinkItem } from "@/lib/profile-data";
import { toHref } from "@/lib/social-catalog";

export const LINK_ICONS: { id: string; Icon: LucideIcon }[] = [
  { id: "globe", Icon: Globe },
  { id: "rocket", Icon: Rocket },
  { id: "users", Icon: Users },
  { id: "heart", Icon: Heart },
  { id: "star", Icon: Star },
  { id: "music", Icon: Music },
  { id: "video", Icon: Video },
  { id: "camera", Icon: Camera },
  { id: "mail", Icon: Mail },
  { id: "shop", Icon: ShoppingBag },
  { id: "game", Icon: Gamepad2 },
  { id: "link", Icon: LinkIcon },
  { id: "work", Icon: Briefcase },
  { id: "calendar", Icon: Calendar },
  { id: "book", Icon: BookOpen },
  { id: "gift", Icon: Gift },
];

const ICON_MAP: Record<string, LucideIcon> = Object.fromEntries(
  LINK_ICONS.map((l) => [l.id, l.Icon]),
);

export function LinkButtons({ links }: { links: LinkItem[] }) {
  return (
    <div className="flex w-full flex-col gap-3">
      {links.map((link, i) => {
        const Icon = ICON_MAP[link.icon] ?? Globe;
        const href = toHref(link.url);
        const clickable = Boolean(href);
        return (
          <a
            key={link.id}
            href={href || undefined}
            target={clickable ? "_blank" : undefined}
            rel={clickable ? "noopener noreferrer" : undefined}
            onClick={clickable ? undefined : (e) => e.preventDefault()}
            className="link-btn rise-in"
            style={{ animationDelay: `${0.15 + i * 0.08}s` }}
          >
            <span
              className="profile-surface profile-accent grid h-9 w-9 shrink-0 place-items-center rounded-lg"
              
            >
              <Icon size={18} />
            </span>
            <span className="flex min-w-0 flex-col text-left">
              <span className="truncate text-sm font-semibold">{link.label}</span>
              {link.sublabel && (
                <span className="profile-muted truncate text-xs">
                  {link.sublabel}
                </span>
              )}
            </span>
            <ArrowUpRight className="link-arrow profile-muted" size={18} />
          </a>
        );
      })}
    </div>
  );
}
