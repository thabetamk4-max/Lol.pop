import { useRef, useState } from 'react';
import { Pause, Play, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { ProfileData } from '@/lib/profile-data';
const fmt=(n:number)=>`${Math.floor((Number.isFinite(n)?n:0)/60)}:${Math.floor((Number.isFinite(n)?n:0)%60).toString().padStart(2,'0')}`;
export function AudioPlayer({track,audioUrl}:{track:ProfileData['track'];audioUrl?:string|null}) {
 const ref=useRef<HTMLAudioElement>(null); const [playing,setPlaying]=useState(false); const [time,setTime]=useState(0); const [duration,setDuration]=useState(0); const [muted,setMuted]=useState(false); const [error,setError]=useState('');
 if (!audioUrl) return null;
 const toggle=async()=>{const el=ref.current;if(!el)return;try{if(playing)el.pause();else await el.play();}catch{setError('Audio could not play.');}};
 return <div className="profile-surface rounded-lg border p-3"><audio key={audioUrl} ref={ref} src={audioUrl} preload="metadata" onPlay={()=>setPlaying(true)} onPause={()=>setPlaying(false)} onEnded={()=>setPlaying(false)} onTimeUpdate={()=>setTime(ref.current?.currentTime??0)} onLoadedMetadata={()=>setDuration(ref.current?.duration??0)} onError={()=>setError('Audio unavailable.')}/><div className="flex items-center gap-3"><Button variant="ghost" size="icon" className="profile-play shrink-0" onClick={toggle} aria-label={playing?'Pause':'Play'}>{playing?<Pause/>:<Play/>}</Button><div className="min-w-0 flex-1"><p className="truncate text-xs font-semibold">{track.title}</p><input aria-label="Audio progress" type="range" min={0} max={Number.isFinite(duration)?duration:0} step={0.1} value={time} onChange={e=>{if(ref.current)ref.current.currentTime=Number(e.target.value);}} className="mt-2 h-1 w-full accent-primary"/><p className="profile-muted mt-1 font-mono text-[10px]">{fmt(time)} / {fmt(duration)}</p></div><Button variant="ghost" size="icon" aria-label={muted?'Unmute':'Mute'} onClick={()=>{if(ref.current){ref.current.muted=!muted;setMuted(!muted);}}}>{muted?<VolumeX/>:<Volume2/>}</Button></div>{error&&<p className="mt-2 text-xs text-destructive">{error}</p>}</div>;
}
