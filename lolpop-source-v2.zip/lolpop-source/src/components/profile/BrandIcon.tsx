import { Globe } from "lucide-react";
import { getPlatform, brandColor, CUSTOM_PLATFORM } from "@/lib/social-catalog";

interface Props {
  platform: string;
  size?: number;
  /** Render in the platform's brand color instead of currentColor. */
  colored?: boolean;
  className?: string;
}

/** Renders a brand glyph for a given platform id (or a globe for custom). */
export function BrandIcon({ platform, size = 22, colored = true, className }: Props) {
  if (platform === CUSTOM_PLATFORM.id) {
    return <Globe size={size} className={className} />;
  }
  const p = getPlatform(platform);
  if (!p) return <Globe size={size} className={className} />;
  return (
    <svg
      role="img"
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill={colored ? brandColor(p.icon.hex) : "currentColor"}
      className={className}
      aria-hidden="true"
    >
      <path d={p.icon.path} />
    </svg>
  );
}
