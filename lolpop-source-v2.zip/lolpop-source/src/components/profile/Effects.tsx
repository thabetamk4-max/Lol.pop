import { useEffect, useRef, useState } from "react";

interface EffectsProps {
  themeId: string;
  particles: "none" | "snow" | "rain";
  blobs: boolean;
  scanlines: boolean;
}

/** Animated glowing background blobs. */
export function Blobs({ enabled }: { enabled: boolean }) {
  if (!enabled) return null;
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div
        className="bg-blob"
        style={{ width: 420, height: 420, top: "-6%", left: "-8%", background: "var(--p-blob1)" }}
      />
      <div
        className="bg-blob"
        style={{
          width: 380,
          height: 380,
          bottom: "-10%",
          right: "-6%",
          background: "var(--p-blob2)",
          animationDelay: "-6s",
        }}
      />
      <div
        className="bg-blob"
        style={{
          width: 300,
          height: 300,
          top: "40%",
          left: "50%",
          background: "var(--p-accent)",
          animationDelay: "-12s",
          opacity: 0.3,
        }}
      />
    </div>
  );
}

/** Falling particles: snow or rain. Client-only to avoid SSR hydration mismatch. */
export function Particles({ mode }: { mode: "none" | "snow" | "rain" }) {
  const [mounted, setMounted] = useState(false);
  const items = useRef(
    Array.from({ length: 60 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      size: 2 + Math.random() * 4,
      delay: Math.random() * 8,
      duration: 6 + Math.random() * 8,
      drift: Math.random() * 0.6 + 0.2,
    })),
  );
  useEffect(() => setMounted(true), []);
  if (mode === "none" || !mounted) return null;
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {items.current.map((p) => (
        <span
          key={p.id}
          className={`particle ${mode === "snow" ? "particle-snow" : "particle-rain"}`}
          style={{
            left: `${p.left}%`,
            width: mode === "snow" ? p.size : undefined,
            height: mode === "snow" ? p.size : undefined,
            opacity: mode === "snow" ? p.drift : undefined,
            animationDelay: `${p.delay}s`,
            animationDuration: `${mode === "rain" ? p.duration * 0.4 : p.duration}s`,
          }}
        />
      ))}
    </div>
  );
}

/** Cyberpunk scanline overlay. */
export function Scanlines({ enabled }: { enabled: boolean }) {
  if (!enabled) return null;
  return <div className="scanline-beam" />;
}

/** Custom glowing cursor that follows the mouse. */
export function CustomCursor({ enabled }: { enabled: boolean }) {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!enabled) return;
    let raf = 0;
    let rx = 0;
    let ry = 0;
    const move = (e: MouseEvent) => {
      setVisible(true);
      if (dot.current) {
        dot.current.style.left = `${e.clientX}px`;
        dot.current.style.top = `${e.clientY}px`;
      }
      cancelAnimationFrame(raf);
      const animate = () => {
        rx += (e.clientX - rx) * 0.18;
        ry += (e.clientY - ry) * 0.18;
        if (ring.current) {
          ring.current.style.left = `${rx}px`;
          ring.current.style.top = `${ry}px`;
        }
        raf = requestAnimationFrame(animate);
      };
      animate();
    };
    window.addEventListener("mousemove", move);
    return () => {
      window.removeEventListener("mousemove", move);
      cancelAnimationFrame(raf);
    };
  }, [enabled]);

  if (!enabled) return null;
  return (
    <>
      <div ref={dot} className="cursor-dot" style={{ opacity: visible ? 1 : 0 }} />
      <div ref={ring} className="cursor-ring" style={{ opacity: visible ? 0.6 : 0 }} />
    </>
  );
}

export type { EffectsProps };
