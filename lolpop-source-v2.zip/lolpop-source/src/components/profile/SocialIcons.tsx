import type { SocialLink } from '@/lib/customization';
import { getPlatform } from '@/lib/social-catalog';
import { socialHref } from '@/lib/profile-settings';
import { BrandIcon } from './BrandIcon';
export function SocialIcons({socials,glow=false,size=22}:{socials:SocialLink[];glow?:boolean;size?:number}) {
 const visible = socials.map(s => ({...s,href:socialHref(s.url,getPlatform(s.platform)?.prefix)})).filter(s=>s.visible && s.href);
 if (!visible.length) return null;
 return <div className="flex flex-wrap items-center justify-center gap-5">{visible.map(s=><a key={s.id} href={s.href} target="_blank" rel="noopener noreferrer" aria-label={s.label} title={s.label} className={`social-icon ${glow?'social-icon--glow':''}`}><BrandIcon platform={s.platform} size={size} colored={false}/></a>)}</div>;
}
