import { Eye, UserRound } from 'lucide-react';
import type { ProfileView } from '@/lib/profile-store';
import { defaultTrack } from '@/lib/profile-store';
import { appearanceDefaults, externalHref } from '@/lib/profile-settings';
import { SocialIcons } from './SocialIcons';
import { LinkButtons } from './LinkButtons';
import { AudioPlayer } from './AudioPlayer';
export function ProfileCard({ view }: { view: ProfileView }) {
 const a = appearanceDefaults(view.appearance);
 const links = view.links.filter(l => l.visible !== false && l.label.trim() && externalHref(l.url));
 return <div className="glass-card rise-in w-full p-6 sm:p-8">
 <div className="flex flex-col items-center text-center">
 <div className="avatar-float avatar-ring relative h-24 w-24">
 {view.avatar ? <img src={view.avatar.url} alt={`${view.displayName} avatar`} width={96} height={96} className="profile-avatar relative z-10 h-24 w-24 object-cover"/> : <div className="profile-avatar relative z-10 grid h-24 w-24 place-items-center"><UserRound className="profile-muted" size={36}/></div>}
 </div>
 <h1 className={`mt-5 break-words text-2xl font-bold ${view.theme === 'cyberpunk' ? 'glitch' : ''}`} data-text={view.displayName}>{view.displayName || view.username}</h1>
 <p className="profile-muted mt-1 text-xs">@{view.username}</p>
 {view.bio && <p className="profile-muted mt-4 whitespace-pre-line break-words text-sm leading-relaxed">{view.bio}</p>}
 {a.showStatus && view.status.some(s => s.trim()) && <div className="profile-surface mt-5 w-full overflow-hidden rounded-md py-2"><div className="marquee-track profile-muted text-xs">{[0,1].map(dup => <span key={dup}>{view.status.filter(s => s.trim()).map((s,i) => <span key={i} className="px-4">✦ {s}</span>)}</span>)}</div></div>}
 {a.showViews && <div className="profile-muted mt-4 flex items-center gap-1.5 text-xs"><Eye size={13}/>{view.views.toLocaleString()} views</div>}
 </div>
 {links.length > 0 && <div className="mt-6"><LinkButtons links={links}/></div>}
 {a.showAudio && view.audio && <div className="mt-5"><AudioPlayer track={{...defaultTrack(),title:view.audio.name,artist:'Now playing'}} audioUrl={view.audio.url}/></div>}
 <div className="mt-6"><SocialIcons socials={view.socialLinks} glow={view.iconGlow} size={a.iconSize}/></div>
 </div>;
}
