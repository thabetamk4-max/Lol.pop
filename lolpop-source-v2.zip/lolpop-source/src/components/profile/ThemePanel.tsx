import { Palette, Settings2, X, Snowflake, CloudRain, Ban, Sparkles, MousePointer2, Scan } from "lucide-react";
import { useState } from "react";
import { THEMES, type ThemeId } from "@/lib/profile-data";

export interface CustomizeState {
  theme: ThemeId;
  particles: "none" | "snow" | "rain";
  blobs: boolean;
  cursor: boolean;
  scanlines: boolean;
}

interface Props {
  state: CustomizeState;
  onChange: (s: CustomizeState) => void;
}

function Toggle({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1.5 rounded-xl border p-3 text-xs font-medium transition-colors"
      style={{
        borderColor: active ? "var(--color-primary)" : "var(--color-border)",
        background: active ? "color-mix(in oklab, var(--color-primary) 18%, transparent)" : "transparent",
        color: active ? "var(--color-foreground)" : "var(--color-muted-foreground)",
      }}
    >
      {icon}
      {label}
    </button>
  );
}

export function ThemePanel({ state, onChange }: Props) {
  const [open, setOpen] = useState(false);
  const set = (patch: Partial<CustomizeState>) => onChange({ ...state, ...patch });

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="Customize"
        className="fixed right-4 top-4 z-50 grid h-12 w-12 place-items-center rounded-full border border-border bg-card/80 text-foreground shadow-lg backdrop-blur-md transition-transform hover:scale-105"
      >
        <Settings2 size={20} />
      </button>

      <div
        className={`fixed right-0 top-0 z-50 h-full w-[300px] max-w-[85vw] transform overflow-y-auto border-l border-border bg-card/95 p-5 shadow-2xl backdrop-blur-xl transition-transform duration-300 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="mb-5 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <Palette size={18} /> Customize
          </h2>
          <button onClick={() => setOpen(false)} aria-label="Close" className="text-muted-foreground hover:text-foreground">
            <X size={20} />
          </button>
        </div>

        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Theme</p>
        <div className="mb-6 flex flex-col gap-2">
          {THEMES.map((t) => (
            <button
              key={t.id}
              onClick={() => set({ theme: t.id })}
              className="flex items-center gap-3 rounded-xl border p-3 text-left transition-colors"
              style={{
                borderColor: state.theme === t.id ? "var(--color-primary)" : "var(--color-border)",
                background:
                  state.theme === t.id
                    ? "color-mix(in oklab, var(--color-primary) 15%, transparent)"
                    : "transparent",
              }}
            >
              <span
                className="h-9 w-9 shrink-0 rounded-lg"
                style={{ background: `linear-gradient(135deg, ${t.swatch[0]}, ${t.swatch[1]})` }}
              />
              <span className="min-w-0">
                <span className="block text-sm font-semibold">{t.name}</span>
                <span className="block truncate text-xs text-muted-foreground">{t.description}</span>
              </span>
            </button>
          ))}
        </div>

        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Particles</p>
        <div className="mb-6 grid grid-cols-3 gap-2">
          <Toggle active={state.particles === "none"} onClick={() => set({ particles: "none" })} icon={<Ban size={18} />} label="None" />
          <Toggle active={state.particles === "snow"} onClick={() => set({ particles: "snow" })} icon={<Snowflake size={18} />} label="Snow" />
          <Toggle active={state.particles === "rain"} onClick={() => set({ particles: "rain" })} icon={<CloudRain size={18} />} label="Rain" />
        </div>

        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Effects</p>
        <div className="grid grid-cols-3 gap-2">
          <Toggle active={state.blobs} onClick={() => set({ blobs: !state.blobs })} icon={<Sparkles size={18} />} label="Blobs" />
          <Toggle active={state.cursor} onClick={() => set({ cursor: !state.cursor })} icon={<MousePointer2 size={18} />} label="Cursor" />
          <Toggle active={state.scanlines} onClick={() => set({ scanlines: !state.scanlines })} icon={<Scan size={18} />} label="Scanlines" />
        </div>
      </div>
    </>
  );
}
