import avatar from "@/assets/avatar.jpg";
import album from "@/assets/album.jpg";

export type ThemeId = "noir" | "cyberpunk" | "glass" | "vintage";

export interface ThemeMeta {
  id: ThemeId;
  name: string;
  className: string;
  description: string;
  swatch: [string, string];
}

export const THEMES: ThemeMeta[] = [
  {
    id: "noir",
    name: "Midnight Noir",
    className: "theme-noir",
    description: "Charcoal, crisp blue accents, quiet contrast.",
    swatch: ["#111214", "#4f91ff"],
  },
  {
    id: "cyberpunk",
    name: "Cyberpunk",
    className: "theme-cyberpunk",
    description: "Neon pink & cyan, glitch text, scanlines.",
    swatch: ["#ff2d95", "#00e5ff"],
  },
  {
    id: "glass",
    name: "Glassmorphism",
    className: "theme-glass",
    description: "Frosted panels, moving blur-gradient.",
    swatch: ["#67e8f9", "#f0abfc"],
  },
  {
    id: "vintage",
    name: "Vintage Retro",
    className: "theme-vintage",
    description: "Faded VHS grain, warm polaroid tones, tape wobble.",
    swatch: ["#d9a679", "#7c4a30"],
  },
];

/** A single tappable link button on the profile. */
export interface LinkItem {
  id: string;
  label: string;
  sublabel?: string;
  url: string;
  icon: string;
  visible?: boolean;
}

/** Default marquee status lines shown for a fresh profile. */
export const DEFAULT_STATUS: string[] = [
  "building things on the internet ✨",
  "coffee → code → repeat",
  "dm's always open",
];

/** Default link buttons for a fresh profile. */
export const DEFAULT_LINKS: LinkItem[] = [
  { id: "l1", label: "My Portfolio", sublabel: "See my work", url: "", icon: "globe" },
  { id: "l2", label: "Latest Project", sublabel: "Now live", url: "", icon: "rocket" },
  { id: "l3", label: "Join the Community", sublabel: "Find your people", url: "", icon: "users" },
  { id: "l4", label: "Support / Donate", sublabel: "Buy me a coffee", url: "", icon: "heart" },
];

export interface ProfileData {
  username: string;
  displayName: string;
  avatar: string;
  badges: string[];
  status: string[];
  views: number;
  socials: { id: string; label: string; href: string }[];
  links: { label: string; sublabel?: string; href: string; icon: string }[];
  track: { title: string; artist: string; cover: string; duration: number };
}

export function getProfile(username: string): ProfileData {
  const clean = username.replace(/[^a-z0-9_.]/gi, "").toLowerCase() || "nova";
  const display = clean.charAt(0).toUpperCase() + clean.slice(1);
  return {
    username: clean,
    displayName: display,
    avatar,
    badges: ["Verified", "Premium", "Early"],
    status: [
      "building things on the internet ✨",
      "coffee → code → repeat",
      "dm's always open",
    ],
    views: 128473,
    socials: [
      { id: "discord", label: "Discord", href: "#" },
      { id: "twitter", label: "Twitter / X", href: "#" },
      { id: "github", label: "GitHub", href: "#" },
      { id: "spotify", label: "Spotify", href: "#" },
      { id: "instagram", label: "Instagram", href: "#" },
      { id: "youtube", label: "YouTube", href: "#" },
      { id: "mail", label: "Email", href: "#" },
    ],
    links: [
      { label: "My Portfolio", sublabel: "See my work", href: "#", icon: "globe" },
      { label: "Latest Project", sublabel: "Now live", href: "#", icon: "rocket" },
      { label: "Join the Community", sublabel: "Find your people", href: "#", icon: "users" },
      { label: "Support / Donate", sublabel: "Buy me a coffee", href: "#", icon: "heart" },
    ],
    track: {
      title: "Neon Skyline",
      artist: "Synthwave Collective",
      cover: album,
      duration: 214,
    },
  };
}
