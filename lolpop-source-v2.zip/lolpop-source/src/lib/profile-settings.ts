export const ACCENTS = ['blue', 'mint', 'rose', 'amber', 'neutral'] as const;
export interface Appearance {
  accent: 'theme' | typeof ACCENTS[number];
  font: 'sans' | 'mono' | 'display';
  opacity: number;
  dimming: number;
  corners: 'sharp' | 'soft';
  linkStyle: 'outline' | 'filled' | 'minimal';
  avatarShape: 'circle' | 'square';
  avatarAnimation: boolean;
  iconSize: number;
  glowIntensity: number;
  showViews: boolean;
  showStatus: boolean;
  showAudio: boolean;
}
export const DEFAULT_APPEARANCE: Appearance = {
  accent: 'theme', font: 'sans', opacity: 85, dimming: 45,
  corners: 'soft', linkStyle: 'outline', avatarShape: 'circle',
  avatarAnimation: false, iconSize: 22, glowIntensity: 8,
  showViews: true, showStatus: true, showAudio: true,
};
export function appearanceDefaults(value?: Partial<Appearance>): Appearance {
  return { ...DEFAULT_APPEARANCE, ...value };
}
export function moveItem<T>(items: T[], index: number, direction: -1 | 1): T[] {
  const next = [...items];
  const destination = index + direction;
  if (index < 0 || index >= items.length || destination < 0 || destination >= items.length) return next;
  [next[index], next[destination]] = [next[destination], next[index]];
  return next;
}
export function externalHref(value: string): string {
  const raw = value.trim();
  if (!raw || /^(javascript|data|blob|file):/i.test(raw)) return '';
  if (/^mailto:[^\s@]+@[^\s@]+\.[^\s@]+$/i.test(raw)) return raw;
  try {
    const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
    if (!['http:', 'https:'].includes(url.protocol) || !url.hostname.includes('.') || url.username || url.password) return '';
    return url.href;
  } catch { return ''; }
}
export function socialHref(value: string, prefix?: string): string {
  const href = externalHref(value);
  if (!href) return '';
  const stripped = (v: string) => v.replace(/^https?:\/\//, '').replace(/\/+$/, '').toLowerCase();
  if (prefix && stripped(value) === stripped(prefix)) return '';
  if (href.startsWith('mailto:')) return href;
  const url = new URL(href);
  if (!url.pathname.replace(/[/@$]/g, '').trim() && !url.search) return '';
  return href;
}
export function assertSaved(result: { error: { message: string } | null; data?: unknown[] | null }) {
  if (result.error) throw new Error(result.error.message);
  if (result.data && result.data.length === 0) throw new Error('Your profile could not be saved.');
}
