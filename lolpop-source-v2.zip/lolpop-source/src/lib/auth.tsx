import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { supabase } from "@/integrations/supabase/client";
import { siteHost } from "@/lib/site";

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  username: string;
}

interface AuthResult {
  ok: boolean;
  error?: string;
  user?: AuthUser;
  confirmationRequired?: boolean;
}

interface Ctx {
  user: AuthUser | null;
  ready: boolean;
  /** Create a new account. Enforces unique email + unique username, server-side. */
  signUp: (email: string, password: string, username: string, next?: string) => Promise<AuthResult>;
  /** Log into an existing account with real credential validation. */
  login: (email: string, password: string) => Promise<AuthResult>;
  signOut: () => Promise<void>;
  /** True when the username is free (checked against the database). */
  usernameAvailable: (username: string) => Promise<boolean>;
}

const AuthContext = createContext<Ctx | null>(null);

function normalizeUsername(raw: string) {
  return raw.trim().replace(/[^a-z0-9_.]/gi, "").toLowerCase();
}

/** Map a Supabase session user + profile row into our AuthUser shape. */
async function hydrateUser(
  authUserId: string,
  email: string | undefined,
): Promise<AuthUser> {
  let username = "";
  let name = "";
  try {
    const { data } = await supabase
      .from("profiles")
      .select("username, display_name")
      .eq("id", authUserId)
      .maybeSingle();
    if (data) {
      username = data.username ?? "";
      name = data.display_name ?? data.username ?? "";
    }
  } catch {
    /* ignore — fall back to email-derived values */
  }
  const fallback = (email ?? "").split("@")[0] ?? "";
  return {
    id: authUserId,
    email: email ?? "",
    username: username || fallback,
    name: name || username || fallback,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;

    // Keep local state in sync with the real auth session.
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (!["INITIAL_SESSION", "SIGNED_IN", "SIGNED_OUT", "USER_UPDATED"].includes(event)) return;
      if (!active) return;
      if (session?.user) {
        // Defer the profile fetch to avoid deadlocks inside the callback.
        setTimeout(() => {
          if (!active) return;
          hydrateUser(session.user.id, session.user.email).then((u) => {
            if (active) setUser(u);
          });
        }, 0);
      } else {
        setUser(null);
      }
    });

    // Restore any existing session on load.
    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      const session = data.session;
      if (session?.user) {
        hydrateUser(session.user.id, session.user.email).then((u) => {
          if (active) {
            setUser(u);
            setReady(true);
          }
        });
      } else {
        setReady(true);
      }
    });

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const usernameAvailable = async (username: string): Promise<boolean> => {
    const clean = normalizeUsername(username);
    if (!clean) return false;
    const { data, error } = await supabase.rpc("is_username_available", {
      _username: clean,
    });
    if (error) return false;
    return Boolean(data);
  };

  const signUp = async (
    email: string,
    password: string,
    username: string,
    next?: string,
  ): Promise<AuthResult> => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanUsername = normalizeUsername(username);

    if (!cleanEmail || !password.trim()) {
      return { ok: false, error: "Email and password are required." };
    }
    if (!cleanUsername || ["auth", "dashboard", "reset-password", "api", "sitemap.xml"].includes(cleanUsername)) {
      return { ok: false, error: "Please choose a username." };
    }
    if (password.length < 6) {
      return { ok: false, error: "Password must be at least 6 characters." };
    }

    const available = await usernameAvailable(cleanUsername);
    if (!available) {
      return { ok: false, error: `${siteHost()}/${cleanUsername} is already taken — pick another.` };
    }

    const { data, error } = await supabase.auth.signUp({
      email: cleanEmail,
      password,
      options: {
        emailRedirectTo: next && next !== "/" ? `${window.location.origin}/auth?next=${encodeURIComponent(next)}` : `${window.location.origin}/auth`,
        data: { username: cleanUsername },
      },
    });

    if (error) {
      if (error.message.toLowerCase().includes("already registered")) {
        return { ok: false, error: "An account with this email already exists. Try logging in." };
      }
      return { ok: false, error: error.message.includes("Database error") ? "That username could not be claimed. Please try another." : error.message };
    }

    const authUser = data.user;
    if (!authUser) {
      return { ok: false, error: "Could not create your account. Please try again." };
    }

    if (!data.session) return { ok: true, confirmationRequired: true };

    const authed: AuthUser = {
      id: authUser.id,
      email: cleanEmail,
      name: cleanUsername,
      username: cleanUsername,
    };
    setUser(authed);
    return { ok: true, user: authed };
  };

  const login = async (email: string, password: string): Promise<AuthResult> => {
    const cleanEmail = email.trim().toLowerCase();
    const { data, error } = await supabase.auth.signInWithPassword({
      email: cleanEmail,
      password,
    });

    if (error) {
      return { ok: false, error: "Incorrect email or password. Try again." };
    }
    if (!data.user) {
      return { ok: false, error: "Could not log in. Please try again." };
    }

    const authed = await hydrateUser(data.user.id, data.user.email);
    setUser(authed);
    return { ok: true, user: authed };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  const value = useMemo(
    () => ({ user, ready, signUp, login, signOut, usernameAvailable }),
    [user, ready],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
