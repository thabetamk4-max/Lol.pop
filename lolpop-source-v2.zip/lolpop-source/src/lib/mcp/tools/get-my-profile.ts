import { defineTool, ToolError } from "@lovable.dev/mcp-js";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "get_my_profile",
  title: "Get my profile",
  description: "Read the signed-in user's lol.pop profile: username, display name, bio, status lines, links and views.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async (_input, ctx) => {
    if (!ctx.isAuthenticated()) throw new ToolError("Not authenticated");
    const { data, error } = await supabaseForUser(ctx)
      .from("profiles")
      .select("username, display_name, customization, views")
      .eq("id", ctx.getUserId()!)
      .maybeSingle();
    if (error) throw new ToolError(error.message);
    if (!data) throw new ToolError("No profile found for this account.");
    const c = (data.customization ?? {}) as Record<string, unknown>;
    const links = Array.isArray(c.links) ? c.links : [];
    const socials = Array.isArray(c.socialLinks) ? c.socialLinks : [];
    const profile = {
      username: data.username,
      displayName: data.display_name ?? data.username,
      bio: typeof c.bio === "string" ? c.bio : "",
      status: Array.isArray(c.status) ? c.status.filter((s): s is string => typeof s === "string") : [],
      links: links.map((l) => {
        const r = (l ?? {}) as Record<string, unknown>;
        return { label: String(r.label ?? ""), url: String(r.url ?? "") };
      }),
      socials: socials.map((l) => {
        const r = (l ?? {}) as Record<string, unknown>;
        return { platform: String(r.platform ?? r.id ?? ""), url: String(r.url ?? "") };
      }),
      views: data.views,
    };
    return { content: [{ type: "text", text: JSON.stringify(profile) }], structuredContent: { profile } };
  },
});
