import { defineTool, ToolError } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "update_profile_text",
  title: "Update profile text",
  description: "Update the signed-in user's display name, bio, or status lines on their lol.pop profile.",
  inputSchema: {
    displayName: z.string().trim().min(1).max(40).optional().describe("New display name."),
    bio: z.string().max(240).optional().describe("New bio text."),
    status: z.array(z.string().trim().min(1).max(80)).max(6).optional().describe("Status lines shown in the scrolling bar."),
  },
  annotations: { readOnlyHint: false, idempotentHint: true, openWorldHint: false },
  handler: async ({ displayName, bio, status }, ctx) => {
    if (!ctx.isAuthenticated()) throw new ToolError("Not authenticated");
    if (displayName === undefined && bio === undefined && status === undefined) throw new ToolError("Nothing to update.");
    const supabase = supabaseForUser(ctx);
    const userId = ctx.getUserId()!;
    const { data, error } = await supabase.from("profiles").select("customization").eq("id", userId).maybeSingle();
    if (error) throw new ToolError(error.message);
    if (!data) throw new ToolError("No profile found for this account.");
    const customization = { ...((data.customization ?? {}) as Record<string, unknown>) };
    if (displayName !== undefined) customization.displayName = displayName;
    if (bio !== undefined) customization.bio = bio;
    if (status !== undefined) customization.status = status;
    const { error: upErr } = await supabase
      .from("profiles")
      .update({ customization: customization as never, ...(displayName !== undefined ? { display_name: displayName } : {}) })
      .eq("id", userId);
    if (upErr) throw new ToolError(upErr.message);
    return { content: [{ type: "text", text: "Profile updated." }] };
  },
});
