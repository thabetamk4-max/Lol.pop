import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Increment a profile's view counter and return the updated row.
 * Runs through the trusted server (service role) because the underlying
 * SECURITY DEFINER function is no longer callable by anon/authenticated.
 */
export const incrementProfileViewsFn = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({ username: z.string().trim().min(1).max(60) }).parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await supabaseAdmin.rpc("increment_profile_views", {
      _username: data.username.toLowerCase(),
    });
    if (error) throw error;
    const row = Array.isArray(rows) ? rows[0] : rows;
    return row ?? null;
  });

/** Increment a template's usage counter through the trusted server. */
export const incrementTemplateUsesFn = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ templateId: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.rpc("increment_template_uses", {
      _template_id: data.templateId,
    });
    if (error) throw error;
    return { ok: true };
  });
