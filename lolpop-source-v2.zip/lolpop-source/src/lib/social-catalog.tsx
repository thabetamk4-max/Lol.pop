import {
  siDiscord,
  siYoutube,
  siRoblox,
  siTiktok,
  siInstagram,
  siSpotify,
  siX,
  siGithub,
  siSnapchat,
  siTelegram,
  siPaypal,
  siSoundcloud,
  siTwitch,
  siReddit,
  siSteam,
  siPinterest,
  siFacebook,
  siThreads,
  siPatreon,
  siKick,
  siCashapp,
  siVenmo,
  siPlaystation,
  siBluesky,
  siApplemusic,
  type SimpleIcon,
} from "simple-icons";

export interface SocialPlatform {
  id: string;
  title: string;
  icon: SimpleIcon;
  /** Placeholder prefix that forms a working URL when combined with a handle. */
  prefix: string;
}

/** Curated platform catalog matching common bio-link platforms. */
export const SOCIAL_PLATFORMS: SocialPlatform[] = [
  { id: "snapchat", title: "Snapchat", icon: siSnapchat, prefix: "snapchat.com/add/" },
  { id: "youtube", title: "YouTube", icon: siYoutube, prefix: "youtube.com/@" },
  { id: "discord", title: "Discord", icon: siDiscord, prefix: "discord.gg/" },
  { id: "spotify", title: "Spotify", icon: siSpotify, prefix: "open.spotify.com/user/" },
  { id: "instagram", title: "Instagram", icon: siInstagram, prefix: "instagram.com/" },
  { id: "x", title: "X", icon: siX, prefix: "x.com/" },
  { id: "tiktok", title: "TikTok", icon: siTiktok, prefix: "tiktok.com/@" },
  { id: "telegram", title: "Telegram", icon: siTelegram, prefix: "t.me/" },
  { id: "soundcloud", title: "SoundCloud", icon: siSoundcloud, prefix: "soundcloud.com/" },
  { id: "paypal", title: "PayPal", icon: siPaypal, prefix: "paypal.me/" },
  { id: "github", title: "GitHub", icon: siGithub, prefix: "github.com/" },
  { id: "roblox", title: "Roblox", icon: siRoblox, prefix: "roblox.com/" },
  { id: "cashapp", title: "Cash App", icon: siCashapp, prefix: "cash.app/$" },
  { id: "venmo", title: "Venmo", icon: siVenmo, prefix: "venmo.com/" },
  { id: "playstation", title: "PlayStation", icon: siPlaystation, prefix: "psnprofiles.com/" },
  { id: "applemusic", title: "Apple Music", icon: siApplemusic, prefix: "music.apple.com/profile/" },
  { id: "twitch", title: "Twitch", icon: siTwitch, prefix: "twitch.tv/" },
  { id: "reddit", title: "Reddit", icon: siReddit, prefix: "reddit.com/user/" },
  { id: "bluesky", title: "Bluesky", icon: siBluesky, prefix: "bsky.app/profile/" },
  { id: "steam", title: "Steam", icon: siSteam, prefix: "steamcommunity.com/id/" },
  { id: "pinterest", title: "Pinterest", icon: siPinterest, prefix: "pinterest.com/" },
  { id: "kick", title: "Kick", icon: siKick, prefix: "kick.com/" },
  { id: "facebook", title: "Facebook", icon: siFacebook, prefix: "facebook.com/" },
  { id: "threads", title: "Threads", icon: siThreads, prefix: "threads.net/@" },
  { id: "patreon", title: "Patreon", icon: siPatreon, prefix: "patreon.com/" },
];

export const CUSTOM_PLATFORM: SocialPlatform = {
  id: "custom",
  title: "Custom URL",
  // reuse an existing icon shape; rendered with globe fallback in UI
  icon: siX,
  prefix: "https://",
};

export function getPlatform(id: string): SocialPlatform | undefined {
  return SOCIAL_PLATFORMS.find((p) => p.id === id);
}

/** Some brand hexes are near-black; render those in a legible light tone on dark UI. */
export function brandColor(hex: string): string {
  const r = parseInt(hex.slice(0, 2), 16);
  const g = parseInt(hex.slice(2, 4), 16);
  const b = parseInt(hex.slice(4, 6), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance < 0.18 ? "#f5f5f5" : `#${hex}`;
}

/** Build a clickable absolute URL from a stored value. */
export { externalHref as toHref } from "./profile-settings";
