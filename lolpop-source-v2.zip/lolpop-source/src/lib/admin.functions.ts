import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

/** Throw unless the verified caller is the platform admin. */
async function hasAdminAccess(client: SupabaseClient<Database>, userId: string) {
  const { data, error } = await client.rpc("has_role", { _user_id: userId, _role: "admin" });
  return !error && data === true;
}
async function assertAdmin(client: SupabaseClient<Database>, userId: string) {
  if (!(await hasAdminAccess(client, userId))) throw new Error("Forbidden: admin only");
}
export const adminAccessFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => hasAdminAccess(context.supabase, context.userId));

export interface AdminTemplate {
  id: string;
  author_username: string;
  name: string;
  uses: number;
  approved: boolean;
  created_at: string;
  avatar_url: string | null;
  background_url: string | null;
  background_type: string | null;
}

export interface AdminProfile {
  id: string;
  username: string;
  display_name: string | null;
  views: number;
  approved: boolean;
  created_at: string;
}

/** List every template (approved or pending) for the admin queue. */
export const adminListTemplatesFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("templates")
      .select("id, author_username, name, uses, approved, created_at, avatar_url, background_url, background_type")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as AdminTemplate[];
  });

/** Approve or reject a template. */
export const adminSetTemplateApprovedFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ id: z.string().uuid(), approved: z.boolean() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("templates")
      .update({ approved: data.approved })
      .eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });

/** Permanently delete a template. */
export const adminDeleteTemplateFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("templates").delete().eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });

/** List every claimed profile/link for the admin directory. */
export const adminListProfilesFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("profiles")
      .select("id, username, display_name, views, approved, created_at")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as AdminProfile[];
  });

/** Approve or suspend a profile. */
export const adminSetProfileApprovedFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ id: z.string().uuid(), approved: z.boolean() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ approved: data.approved })
      .eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });

/** Permanently delete a claimed link (frees the username). */
export const adminDeleteProfileFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("templates").delete().eq("author_id", data.id);
    const { error } = await supabaseAdmin.from("profiles").delete().eq("id", data.id);
    if (error) throw error;
    return { ok: true };
  });
