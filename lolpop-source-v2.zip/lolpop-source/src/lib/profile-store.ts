import { appearanceDefaults, assertSaved, type Appearance } from "./profile-settings";
import { supabase } from "@/integrations/supabase/client";
import { incrementProfileViewsFn, incrementTemplateUsesFn } from "./profile.functions";
import {
  DEFAULT_LINKS,
  DEFAULT_STATUS,
  getProfile,
  type LinkItem,
  type ThemeId,
} from "./profile-data";
import type { AssetRef, CustomizationState, SocialLink } from "./customization";
import type { Json } from "@/integrations/supabase/types";

/** Everything the ProfileCard needs to render, from either the DB or live edits. */
export interface ProfileView {
  username: string;
  bio: string;
  appearance: Appearance;
  displayName: string;
  theme: ThemeId;
  particles: "none" | "snow" | "rain";
  blobs: boolean;
  cursor: boolean;
  scanlines: boolean;
  iconGlow: boolean;
  status: string[];
  links: LinkItem[];
  socialLinks: SocialLink[];
  avatar: AssetRef | null;
  background: AssetRef | null;
  audio: AssetRef | null;
  views: number;
}

/** Serializable slice of the customization state stored in the JSONB column. */
export interface CustomizationJson {
  bio?: string;
  appearance?: Partial<Appearance>;
  displayName?: string;
  theme?: ThemeId;
  particles?: "none" | "snow" | "rain";
  blobs?: boolean;
  cursor?: boolean;
  scanlines?: boolean;
  iconGlow?: boolean;
  status?: string[];
  links?: LinkItem[];
  socialLinks?: SocialLink[];
}

interface ProfileRow {
  username: string;
  display_name: string | null;
  customization: Json;
  avatar_url: string | null;
  background_url: string | null;
  background_type: string | null;
  audio_url: string | null;
  audio_name: string | null;
  views: number;
}

function asset(url: string | null, type: string | null, name: string): AssetRef | null {
  if (!url) return null;
  return { url, type: type ?? "image/*", name };
}

/** Build the render view-model from a DB profile row. */
export function rowToView(row: ProfileRow): ProfileView {
  const c = (row.customization ?? {}) as CustomizationJson;
  const display = row.display_name || c.displayName || row.username;
  return {
    username: row.username,
    bio: c.bio ?? "",
    appearance: appearanceDefaults(c.appearance),
    displayName: display,
    theme: c.theme ?? "noir",
    particles: c.particles ?? "none",
    blobs: c.blobs ?? false,
    cursor: c.cursor ?? false,
    scanlines: c.scanlines ?? false,
    iconGlow: c.iconGlow ?? false,
    status: c.status ?? [...DEFAULT_STATUS],
    links: c.links ?? DEFAULT_LINKS.map((l) => ({ ...l })),
    socialLinks: c.socialLinks ?? [],
    avatar: asset(row.avatar_url, "image/*", "avatar"),
    background: asset(row.background_url, row.background_type, "background"),
    audio: asset(row.audio_url, "audio/*", row.audio_name || "audio"),
    views: row.views ?? 0,
  };
}

/** Build the render view-model from the live customization state (dashboard preview). */
export function stateToView(state: CustomizationState, views: number): ProfileView {
  return {
    username: state.username,
    bio: state.bio,
    appearance: appearanceDefaults(state.appearance),
    displayName: state.displayName || state.username,
    theme: state.theme,
    particles: state.particles,
    blobs: state.blobs,
    cursor: state.cursor,
    scanlines: state.scanlines,
    iconGlow: state.iconGlow,
    status: state.status,
    links: state.links,
    socialLinks: state.socialLinks,
    avatar: state.avatar,
    background: state.background,
    audio: state.audio,
    views,
  };
}

/** Turn a DB row into an editable customization state (dashboard hydration). */
export function rowToState(row: ProfileRow): CustomizationState {
  const v = rowToView(row);
  return {
    username: v.username,
    bio: v.bio,
    appearance: v.appearance,
    displayName: v.displayName,
    theme: v.theme,
    particles: v.particles,
    blobs: v.blobs,
    cursor: v.cursor,
    scanlines: v.scanlines,
    iconGlow: v.iconGlow,
    status: v.status,
    links: v.links,
    socialLinks: v.socialLinks,
    avatar: v.avatar,
    background: v.background,
    audio: v.audio,
  };
}

const ROW_COLS =
  "username, display_name, customization, avatar_url, background_url, background_type, audio_url, audio_name, views";

/** Load the signed-in user's own profile (no view increment). */
export async function loadOwnProfile(userId: string): Promise<ProfileRow | null> {
  const { data, error } = await supabase
    .from("profiles")
    .select(ROW_COLS)
    .eq("id", userId)
    .maybeSingle();
  if (error) throw error;
  return data as ProfileRow | null;
}

/** Load a public profile by username AND count the visit. */
export async function fetchAndCountProfile(username: string): Promise<ProfileView | null> {
  const clean = username.trim().toLowerCase();
  try {
    const row = (await incrementProfileViewsFn({ data: { username: clean } })) as
      | (ProfileRow & { approved?: boolean })
      | null;
    if (!row) return null;
    // A suspended link behaves like an unclaimed one.
    if (row.approved === false) return null;
    return rowToView(row);
  } catch {
    return null;
  }
}

/** Persist the current customization + asset URLs for the signed-in user. */
export async function saveProfile(userId: string, state: CustomizationState): Promise<void> {
  const customization: CustomizationJson = {
    bio: state.bio,
    appearance: state.appearance,
    displayName: state.displayName,
    theme: state.theme,
    particles: state.particles,
    blobs: state.blobs,
    cursor: state.cursor,
    scanlines: state.scanlines,
    iconGlow: state.iconGlow,
    status: state.status,
    links: state.links,
    socialLinks: state.socialLinks,
  };
  const result = await supabase
    .from("profiles")
    .update({
      display_name: state.displayName || state.username,
      customization: customization as unknown as Json,
      avatar_url: state.avatar?.url ?? null,
      background_url: state.background?.url ?? null,
      background_type: state.background?.type ?? null,
      audio_url: state.audio?.url ?? null,
      audio_name: state.audio?.name ?? null,
    })
    .eq("id", userId)
    .select("id");
  assertSaved(result);
}

const YEAR = 60 * 60 * 24 * 365;

/** Upload a file to the user's folder and return a long-lived signed URL. */
export async function uploadAsset(
  userId: string,
  file: File,
  kind: "avatar" | "background" | "audio",
): Promise<AssetRef> {
  const ext = file.name.split(".").pop() || "bin";
  const path = `${userId}/${kind}-${Date.now()}.${ext}`;
  const { error } = await supabase.storage
    .from("profile-assets")
    .upload(path, file, { upsert: true, contentType: file.type });
  if (error) throw error;
  const { data, error: signErr } = await supabase.storage
    .from("profile-assets")
    .createSignedUrl(path, YEAR);
  if (signErr || !data) throw signErr ?? new Error("Could not sign uploaded file");
  return { url: data.signedUrl, name: file.name, type: file.type };
}

/* -------------------------------- Templates -------------------------------- */

export interface TemplateRecord {
  id: string;
  author_id: string;
  approved: boolean;
  author_username: string;
  name: string;
  customization: CustomizationJson;
  avatar_url: string | null;
  background_url: string | null;
  background_type: string | null;
  uses: number;
  created_at: string;
}

export async function listTemplates(): Promise<TemplateRecord[]> {
  const { data, error } = await supabase
    .from("templates")
    .select("id, author_id, approved, author_username, name, customization, avatar_url, background_url, background_type, uses, created_at")
    .order("created_at", { ascending: false })
    .limit(60);
  if (error) throw error;
  if (!data) return [];
  return data as unknown as TemplateRecord[];
}

/** Publish the current design as a public template. */
export async function publishTemplate(
  userId: string,
  authorUsername: string,
  name: string,
  state: CustomizationState,
): Promise<{ ok: boolean; error?: string }> {
  const customization: CustomizationJson = {
    bio: state.bio,
    appearance: state.appearance,
    displayName: state.displayName,
    theme: state.theme,
    particles: state.particles,
    blobs: state.blobs,
    cursor: state.cursor,
    scanlines: state.scanlines,
    iconGlow: state.iconGlow,
    status: state.status,
    links: state.links,
    socialLinks: state.socialLinks,
  };
  const { error } = await supabase.from("templates").insert({
    author_id: userId,
    author_username: authorUsername,
    name: name.trim() || `${authorUsername}'s template`,
    customization: customization as unknown as Json,
    avatar_url: state.avatar?.url ?? null,
    background_url: state.background?.url ?? null,
    background_type: state.background?.type ?? null,
  });
  if (error) return { ok: false, error: error.message };
  return { ok: true };
}

export async function deleteTemplate(id: string): Promise<void> {
  const { error } = await supabase.from("templates").delete().eq("id", id);
  if (error) throw error;
}

/** Apply a template to the current editing state (does not touch username). */
export function templateToPatch(t: TemplateRecord): Partial<CustomizationState> {
  const c = t.customization ?? {};
  return {
    theme: c.theme ?? "noir",
    particles: c.particles ?? "none",
    blobs: c.blobs ?? false,
    cursor: c.cursor ?? false,
    scanlines: c.scanlines ?? false,
    iconGlow: c.iconGlow ?? false,
    appearance: appearanceDefaults(c.appearance),
    avatar: t.avatar_url ? { url: t.avatar_url, type: "image/*", name: "avatar" } : null,
    background: t.background_url
      ? { url: t.background_url, type: t.background_type ?? "image/*", name: "background" }
      : null,
  };
}

export async function markTemplateUsed(id: string): Promise<void> {
  await incrementTemplateUsesFn({ data: { templateId: id } });
}

/** Default track metadata (audio waveform placeholder art). */
export function defaultTrack() {
  return getProfile("nova").track;
}
