import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { DEFAULT_APPEARANCE, appearanceDefaults, type Appearance } from "./profile-settings";
import { DEFAULT_LINKS, DEFAULT_STATUS, type LinkItem, type ThemeId } from "./profile-data";

export interface AssetRef {
  url: string;
  name: string;
  type: string;
}

export interface SocialLink {
  /** unique instance id */
  id: string;
  /** platform id from the social catalog (or "custom") */
  platform: string;
  /** label shown on the management card (platform title, editable for custom) */
  label: string;
  /** the user-entered value (domain + handle) */
  url: string;
  /** whether the icon appears on the live profile */
  visible: boolean;
}

export interface CustomizationState {
  username: string;
  bio: string;
  appearance: Appearance;
  displayName: string;
  theme: ThemeId;
  particles: "none" | "snow" | "rain";
  blobs: boolean;
  cursor: boolean;
  scanlines: boolean;
  iconGlow: boolean;
  background: AssetRef | null;
  audio: AssetRef | null;
  avatar: AssetRef | null;
  socialLinks: SocialLink[];
  /** Marquee status lines (first reference pic). */
  status: string[];
  /** Tappable link buttons (second reference pic). */
  links: LinkItem[];
}

export const DEFAULT_STATE: CustomizationState = {
  username: "",
  bio: "",
  appearance: DEFAULT_APPEARANCE,
  displayName: "",
  theme: "noir",
  particles: "none",
  blobs: false,
  cursor: false,
  scanlines: false,
  iconGlow: false,
  background: null,
  audio: null,
  avatar: null,
  socialLinks: [],
  status: [...DEFAULT_STATUS],
  links: DEFAULT_LINKS.map((l) => ({ ...l })),
};

const STORAGE_KEY = "aboutme:customization";

interface Ctx {
  state: CustomizationState;
  update: (patch: Partial<CustomizationState>) => void;
  /** Replace the whole state from a persisted source without echoing back. */
  hydrate: (next: CustomizationState) => void;
  /** True once server data (or a fresh default) has been loaded. */
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  reset: () => void;
}

const CustomizationContext = createContext<Ctx | null>(null);

/** Persist the lightweight, serialisable fields (not object URLs). */
function persist(state: CustomizationState) {
  if (typeof window === "undefined") return;
  const { background, audio, avatar, ...rest } = state;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(rest));
  } catch {
    /* ignore quota errors */
  }
}

function loadPersisted(): Partial<CustomizationState> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Partial<CustomizationState>) : {};
  } catch {
    return {};
  }
}

export function CustomizationProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<CustomizationState>(DEFAULT_STATE);
  const [hydrated, setHydrated] = useState(false);
  const hydratedRef = useRef(false);

  // Hydrate persisted prefs on the client only (avoids SSR mismatch).
  // This is a draft cache; the dashboard replaces it with server data once loaded.
  useEffect(() => {
    if (hydratedRef.current) return;
    // Account-specific cloud state is hydrated by the editor. Never restore another account's draft.
  }, []);

  const update = (patch: Partial<CustomizationState>) =>
    setState((s) => {
      const next = { ...s, ...patch, appearance: appearanceDefaults(patch.appearance ?? s.appearance) };
      persist(next);
      return next;
    });

  const hydrate = (next: CustomizationState) => {
    hydratedRef.current = true;
    setState({ ...DEFAULT_STATE, ...next, appearance: appearanceDefaults(next.appearance) });
    persist(next);
    setHydrated(true);
  };

  const reset = () => {
    hydratedRef.current = false;
    setHydrated(false);
    setState(DEFAULT_STATE);
    persist(DEFAULT_STATE);
  };

  const value = useMemo(
    () => ({ state, update, hydrate, hydrated, setHydrated, reset }),
    [state, hydrated],
  );

  return (
    <CustomizationContext.Provider value={value}>{children}</CustomizationContext.Provider>
  );
}

export function useCustomization() {
  const ctx = useContext(CustomizationContext);
  if (!ctx) throw new Error("useCustomization must be used within CustomizationProvider");
  return ctx;
}
