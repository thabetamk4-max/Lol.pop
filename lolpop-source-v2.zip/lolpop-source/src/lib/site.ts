/**
 * The public host to show in "your link is …" copy and to build shareable URLs.
 * Uses the real current host in the browser so copied links actually resolve,
 * and falls back to the published domain during SSR.
 */
export function siteHost(): string {
  if (typeof window !== "undefined") return window.location.host;
  return "aboutmehub.lovable.app";
}

/** Full shareable profile URL for a username, e.g. https://aboutmehub.lovable.app/nova */
export function profileUrl(username: string): string {
  const proto = typeof window !== "undefined" ? window.location.protocol : "https:";
  return `${proto}//${siteHost()}/${username}`;
}
