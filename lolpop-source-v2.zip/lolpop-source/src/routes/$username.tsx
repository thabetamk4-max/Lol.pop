import { createFileRoute, Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { Loader2, Settings2, UserX } from 'lucide-react';
import { fetchAndCountProfile, type ProfileView } from '@/lib/profile-store';
import { ProfileCard } from '@/components/profile/ProfileCard';
import { ProfileScene } from '@/components/profile/ProfileScene';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/auth';
import { pageMeta } from '@/lib/metadata';
export const Route=createFileRoute('/$username')({head:({params})=>({meta:pageMeta(`@${params.username}`,`Links, music, and more from @${params.username} on lol.pop.`)}),component:ProfilePage});
function ProfilePage(){const {username}=Route.useParams();const {user}=useAuth();const [view,setView]=useState<ProfileView|null>(null);const [status,setStatus]=useState<'loading'|'ready'|'missing'>('loading');useEffect(()=>{let active=true;setStatus('loading');void fetchAndCountProfile(username).then(v=>{if(active){setView(v);setStatus(v?'ready':'missing');}});return()=>{active=false;};},[username]);if(status==='loading')return <main className="flex min-h-dvh items-center justify-center"><Loader2 className="animate-spin text-primary"/></main>;if(!view)return <main className="flex min-h-dvh flex-col items-center justify-center gap-4 px-5 text-center"><UserX className="text-muted-foreground"/><h1 className="max-w-full break-words text-2xl font-semibold">@{username} is unavailable</h1><p className="text-sm text-muted-foreground">This profile hasn’t been claimed or is not available.</p><Button asChild><Link to="/auth">Create your space</Link></Button></main>;return <><ProfileScene view={view}><ProfileCard view={view}/><p className="profile-muted mt-6 text-center text-[10px]">made on <Link to="/" className="font-display font-semibold">lol.pop</Link></p></ProfileScene>{user?.username===view.username&&<Button asChild variant="outline" size="sm" className="fixed right-4 top-4 z-50"><Link to="/dashboard" search={{section:"customize"}}><Settings2/>Edit profile</Link></Button>}</>;}
