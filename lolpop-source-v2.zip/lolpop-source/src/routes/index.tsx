import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { pageMeta } from '@/lib/metadata';
export const Route=createFileRoute('/')({head:()=>({meta:pageMeta('Your corner of the internet','Create your personal link-in-bio profile with lol.pop.')}),component:Entry});
function Entry(){const {user,ready}=useAuth();const navigate=useNavigate();useEffect(()=>{if(ready)void (user?navigate({to:'/dashboard',search:{section:'customize'},replace:true}):navigate({to:'/auth',replace:true}));},[ready,user,navigate]);return <main className="flex min-h-dvh flex-col items-center justify-center gap-5"><span className="font-display text-3xl font-bold">lol<span className="text-primary">.</span>pop</span><Loader2 className="animate-spin text-muted-foreground" size={20}/></main>;}
