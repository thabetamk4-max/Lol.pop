# lol.pop — open-source link-in-bio

Customizable profile pages (`yoursite.com/username`) with themes, effects, background video/audio, social links, templates and a dashboard. Built with TanStack Start, React 19, Tailwind v4 and Supabase.

## Run locally
1. Install [Bun](https://bun.sh).
2. `bun install`
3. Create a free project at supabase.com, open the SQL editor and run `supabase/setup.sql` (tables, roles, storage, security rules).
4. Copy `.env.example` to `.env` and fill in your project URL and anon key.
5. `bun run dev` → http://localhost:8080

To make yourself admin: `insert into public.user_roles (user_id, role) values ('<your-user-id>', 'admin');`

## Deploy free
- **Cloudflare Workers/Pages** (recommended): `bun run build`, then connect the GitHub repo; add the `.env` values as environment variables.
- **Vercel / Netlify**: import the repo, build command `bun run build`, add the same variables.

## Put it on GitHub
Create an empty repo, then in this folder:
```
git init && git add . && git commit -m "lol.pop"
git branch -M main
git remote add origin https://github.com/<you>/lolpop.git
git push -u origin main
```
Or upload the folder via "Add file → Upload files" on github.com.

## License
MIT
